-- Q1 Write a SQL query to count the number of characters except for the spaces for each actor. 
-- Return the first 10 actors' name lengths along with their names

use mavenmovies;
select concat(first_name,' ',last_name) as Actor_name,
length(concat(first_name,last_name)) length_name 
from actor
LIMIT 10;
 
-- Q2 List all Oscar awardees(Actors who received the Oscar award) with their full names and the length of their names 

select concat(first_name,' ',last_name) as Oscar_awardees,
length(concat(first_name,last_name)) as Length_name,
awards
 from actor_award 
WHERE awards LIKE '%Oscar%';

-- Q3 Find the actors who have acted in the film ‘Frost Head.’

select (CONCAT(first_name, ' ', last_name)) as ActorNames,f.title
 from film f
inner join film_actor fa
on f.film_id=fa.film_id
inner join actor a
on a.actor_id=fa.actor_id
where f.title='Frost Head';

-- Q4 Pull all the films acted by the actor ‘Will Wilson.’

select title,concat(first_name,' ',last_name ) actor_name
from film_actor
inner join actor 
on film_actor.actor_id=actor.actor_id
inner join film
on film.film_id=film_actor.film_id
where actor.first_name='will'and actor.last_name='wilson';

-- Q5 Pull all the films which were rented and return them in the month of May.

SELECT  title Films_rented_and_returned_on_May,rental_date,return_date
FROM film f 
inner JOIN inventory iy
 ON f.film_id = iy.film_id
 inner JOIN rental r 
 ON iy.inventory_id = r.inventory_id
WHERE
MONTH(rental_date) = 5
AND MONTH(return_date) = 5;

-- Q6   Pull all the films with ‘Comedy’ category.


select title,c.name as category
from film fm
inner join film_category fc
on fm.film_id=fc.film_id
inner join category c
on c.category_id=fc.category_id
where c.name='comedy';